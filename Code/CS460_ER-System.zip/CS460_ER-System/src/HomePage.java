import javax.swing.*;

public class HomePage {
    private JTabbedPane tabbedPane1;
    private JPanel panel1;


}
